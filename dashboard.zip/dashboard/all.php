
<?php
SESSION_START(); 
?>
  <head>
    <meta charset="utf-8">

		<link rel="stylesheet" href="mdl/material.min.css">
		<script src="mdl/material.min.js"></script>
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  </head>

  <body class="index">
	<div class="mdl-grid" id="alldiv">
		
		<div class="mdl-cell mdl-cell--2-col">
		<img src="http://placehold.it/350x150">
		</div>
		
		<div class="mdl-cell mdl-cell--2-col">
		</div>
		
		<div class="mdl-cell mdl-cell--4-col">
		<h1>Ampelsystem</h1>
		</div>
		
		<div class="mdl-cell mdl-cell--2-col ">
		</div>
		
		<div class="mdl-card mdl-cell mdl-cell--2-col mdl-shadow--2dp">
			<div class="mdl-card__title">
			<?php
			echo '<h2 class="mdl-card__title-text">'.$_SESSION["username"].'</h2>';
			?>
			</div>
		</div>
		
		
		<div id="fachdiv" class="mdl-cell mdl-cell--2-col">
		<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp">
		  <thead>
			<tr>
			  <th class="mdl-data-table__cell--non-numeric"><h5>Fach</h5></th>
			  <th></th>
			</tr>
		  </thead>
		  <tbody>
			<tr>
			  <td class="mdl-data-table__cell--non-numeric">MEDT</td>
			  <td><input type="radio" name="fach" class="mdl-radio mdl-js-radio mdl-radio__button mdl-js-ripple-effect"></td>
			</tr>
			<tr>
			  <td class="mdl-data-table__cell--non-numeric">SEW</td>
			  <td><input type="radio" name="fach" class="mdl-radio mdl-js-radio mdl-radio__button mdl-js-ripple-effect"></td>
			</tr>
			<tr>
			  <td class="mdl-data-table__cell--non-numeric">AM</td>
			  <td><input type="radio" name="fach" class="mdl-radio mdl-js-radio mdl-radio__button mdl-js-ripple-effect"></td>
			</tr>
		  </tbody>
		</table>
		</div>
		
		<div class="mdl-cell mdl-cell--2-col ">
		</div>
   
		<div id="ampeldiv" class="mdl-cell mdl-cell--6-col">
		<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp">
		  <thead>
			<tr>
			  <th class="mdl-data-table__cell--non-numeric"><h5>Vorname</h5></th>
			  <th class="mdl-data-table__cell--non-numeric"><h5>Nachname</h5></th>
			  <th class="mdl-data-table__cell--non-numeric"><h5>Rot</h5></th>
			  <th class="mdl-data-table__cell--non-numeric"><h5>Gelb</h5></th>
			  <th class="mdl-data-table__cell--non-numeric"><h5>Grün</h5></th>
			</tr>
		  </thead>
		  <tbody>
			<tr>
			  <td class="mdl-data-table__cell--non-numeric">Michael</td>
			  <td class="mdl-data-table__cell--non-numeric">Jindra</td>
			  <td><input type="radio" name="n1"></td>
			  <td><input type="radio" name="n1"></td>
			  <td><input type="radio" name="n1"></td>
			</tr>
			<tr>
			  <td class="mdl-data-table__cell--non-numeric">Nemanja</td>
			  <td class="mdl-data-table__cell--non-numeric">Filipovic</td>
			  <td ><input type="radio" name="n2"></td>
			  <td ><input type="radio" name="n2"></td>
			  <td ><input type="radio" name="n2"></td>
			</tr>
		  </tbody>
		</table>
		</div>
		
		<div class="mdl-cell mdl-cell--2-col">
		</div>
		
		<div id="Klassediv" class="mdl-cell mdl-cell--2-col">
		<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp">
		  <thead>
			<tr>
			  <th class="mdl-data-table__cell--non-numeric"><h5>Klasse</h5></th>
			  <th></th>
			</tr>
		  </thead>
		  <tbody>
			<tr>
			  <td class="mdl-data-table__cell--non-numeric">1AHIT</td>
			  <td><input type="radio" name="klasse" class="mdl-radio mdl-js-radio mdl-radio__button mdl-js-ripple-effect"></td>
			</tr>
			<tr>
			  <td class="mdl-data-table__cell--non-numeric">2CHIT</td>
			  <td><input type="radio" name="klasse" class="mdl-radio mdl-js-radio mdl-radio__button mdl-js-ripple-effect"></td>
			</tr>
			<tr>
			  <td class="mdl-data-table__cell--non-numeric">4YHIT</td>
			  <td><input type="radio" name="klasse" class="mdl-radio mdl-js-radio mdl-radio__button mdl-js-ripple-effect"></td>
			</tr>
		  </tbody>
		</table>
		</div>
		
		</div>
	</div>
  </body>
</html>
<?php ?> 